import { z } from "zod";
export const TutorRequest = z.object({
  provider: z.enum(["openai","anthropic"]),
  prompt: z.string().min(1).max(12000),
  context: z.string().max(12000).optional()
});
export type TutorRequest = z.infer<typeof TutorRequest>;
// Provider calls belong on the server. Never expose API keys in NEXT_PUBLIC_* variables.
export async function askTutor(input:TutorRequest) {
  if(input.provider==="openai") {
    if(!process.env.OPENAI_API_KEY) throw new Error("OPENAI_API_KEY is not configured.");
    const r=await fetch("https://api.openai.com/v1/responses",{method:"POST",headers:{"Content-Type":"application/json","Authorization":`Bearer ${process.env.OPENAI_API_KEY}`},body:JSON.stringify({model:"gpt-4.1-mini",input:[{role:"system",content:"You are a rigorous SAT tutor. Explain the underlying skill, recognition clue, reliable solution and common trap. Never claim generated questions are official."},{role:"user",content:`${input.context??""}\\n${input.prompt}`} ]})});
    if(!r.ok) throw new Error(`OpenAI request failed (${r.status}).`);
    const data=await r.json(); return data.output_text ?? "No response text returned.";
  }
  if(!process.env.ANTHROPIC_API_KEY) throw new Error("ANTHROPIC_API_KEY is not configured.");
  const r=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json","x-api-key":process.env.ANTHROPIC_API_KEY,"anthropic-version":"2023-06-01"},body:JSON.stringify({model:"claude-3-7-sonnet-latest",max_tokens:1400,system:"You are a rigorous SAT tutor. Explain the underlying skill, recognition clue, reliable solution and common trap. Never claim generated questions are official.",messages:[{role:"user",content:`${input.context??""}\\n${input.prompt}`} ]})});
  if(!r.ok) throw new Error(`Anthropic request failed (${r.status}).`);
  const data=await r.json(); return data.content?.map((c:any)=>c.text??"").join("\\n")??"No response text returned.";
}