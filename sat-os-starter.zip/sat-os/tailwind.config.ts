import type { Config } from "tailwindcss";
const config: Config = { content:["./app/**/*.{js,ts,jsx,tsx}","./components/**/*.{js,ts,jsx,tsx}"], theme:{extend:{colors:{ink:"#090B10",panel:"#11151D",line:"#252B37",muted:"#8D96A8",accent:"#B8A4FF"}}}, plugins:[] };
export default config;