# SAT OS

Private SAT mastery workspace. Dark, premium interface. Target: 1550–1600.

## Stack
- Next.js App Router + TypeScript
- Tailwind CSS
- PostgreSQL via Supabase (schema included)
- Server-side provider adapters for OpenAI and Anthropic
- GitHub as the shared source of truth for Claude Code and ChatGPT

## Run locally
1. Install Node.js 20+.
2. `npm install`
3. Copy `.env.example` to `.env.local`.
4. Add API keys only if you want to enable the tutor.
5. `npm run dev`

Open http://localhost:3000.

## Current MVP
- Dark dashboard
- SAT domain library
- Pattern trainer with original sample questions
- 12-week plan
- Exam simulator placeholder linking to Bluebook
- Analytics placeholders
- Server-side OpenAI and Anthropic tutor endpoint

## Next implementation milestones
1. Supabase authentication and private access.
2. Persistent question library, attempts, sessions and error log.
3. Recognition/solving timers and spaced repetition.
4. Question import workflow with provenance and rights metadata.
5. Full digital SAT simulator and score reporting.
6. AI tutor UI, provider selection, rate limits and audit logs.

## Data integrity
Official College Board questions, licensed content, student-recalled reconstructions and original questions must remain distinct. Do not scrape or redistribute protected material without permission. Do not claim reconstructed questions are authentic live exam forms.

## Security
- Keep `OPENAI_API_KEY` and `ANTHROPIC_API_KEY` server-side.
- Add Supabase Auth before exposing the app beyond local development.
- Restrict the production deployment to the intended user.
- Add rate limiting and request logging before enabling AI endpoints publicly.
