-- SAT OS initial relational schema. Apply in Supabase SQL editor.
create extension if not exists pgcrypto;
create table if not exists profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 display_name text,
 target_score_min int not null default 1550,
 target_score_max int not null default 1600,
 created_at timestamptz not null default now()
);
create table if not exists questions (
 id uuid primary key default gen_random_uuid(),
 section text not null check(section in ('maths','reading_writing')),
 domain text not null,
 skill text not null,
 difficulty text not null check(difficulty in ('easy','medium','hard')),
 prompt text not null,
 choices jsonb not null default '[]',
 answer_key text,
 explanation text,
 recognition_clues text[] not null default '{}',
 solving_method text,
 common_traps text[] not null default '{}',
 source_type text not null check(source_type in ('official_link','licensed','student_recalled','original')),
 source_label text,
 test_date date,
 provenance_url text,
 created_at timestamptz not null default now()
);
create table if not exists attempts (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references profiles(id) on delete cascade,
 question_id uuid not null references questions(id) on delete cascade,
 selected_answer text,
 is_correct boolean not null,
 recognition_ms int,
 solving_ms int,
 confidence smallint check(confidence between 1 and 5),
 attempted_at timestamptz not null default now()
);
create table if not exists study_sessions (
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references profiles(id) on delete cascade,
 session_date date not null default current_date,
 planned_minutes int not null default 90,
 completed_minutes int not null default 0,
 focus_domains text[] not null default '{}',
 notes text
);
alter table profiles enable row level security;
alter table questions enable row level security;
alter table attempts enable row level security;
alter table study_sessions enable row level security;
create policy "Users manage own profile" on profiles for all using (auth.uid()=id) with check (auth.uid()=id);
create policy "Authenticated users read question library" on questions for select to authenticated using (true);
create policy "Users manage own attempts" on attempts for all using (auth.uid()=user_id) with check (auth.uid()=user_id);
create policy "Users manage own sessions" on study_sessions for all using (auth.uid()=user_id) with check (auth.uid()=user_id);